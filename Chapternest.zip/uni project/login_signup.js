
const showLogin = document.getElementById("showLogin");
const showSignup = document.getElementById("showSignup");
const loginForm = document.getElementById("loginForm");
const signupForm = document.getElementById("signupForm");
const messageBox = document.getElementById("messageBox");
const forgotPassword = document.getElementById("forgotPassword");

function showMessage(text, type) {
  messageBox.textContent = text;
  messageBox.className = "message-box " + type;
}

function clearMessage() {
  messageBox.textContent = "";
  messageBox.className = "message-box";
}

function switchToLogin() {
  showLogin.classList.add("active");
  showSignup.classList.remove("active");
  loginForm.classList.add("active-form");
  signupForm.classList.remove("active-form");
  clearMessage();
}

function switchToSignup() {
  showSignup.classList.add("active");
  showLogin.classList.remove("active");
  signupForm.classList.add("active-form");
  loginForm.classList.remove("active-form");
  clearMessage();
}

function getSavedUser() {
  return JSON.parse(localStorage.getItem("chapterNestUser")) ||
         JSON.parse(localStorage.getItem("bookstoreUser")) ||
         null;
}

function saveLoggedInUser(name) {
  localStorage.setItem("chapterNestLoggedIn", "true");
  localStorage.setItem("chapterNestLoggedInUser", name || "Reader");

  // Compatibility with the older project files
  localStorage.setItem("bookstoreLoggedIn", "true");
  localStorage.setItem("bookstoreLoggedInUser", name || "Reader");
}

showLogin.addEventListener("click", switchToLogin);
showSignup.addEventListener("click", switchToSignup);

signupForm.addEventListener("submit", function (event) {
  event.preventDefault();

  const name = document.getElementById("signupName").value.trim();
  const email = document.getElementById("signupEmail").value.trim().toLowerCase();
  const password = document.getElementById("signupPassword").value;
  const confirmPassword = document.getElementById("confirmPassword").value;

  if (password.length < 6) {
    showMessage("Password must be at least 6 characters.", "error");
    return;
  }

  if (password !== confirmPassword) {
    showMessage("Passwords do not match.", "error");
    return;
  }

  const user = { name, email, password };

  localStorage.setItem("chapterNestUser", JSON.stringify(user));
  localStorage.setItem("bookstoreUser", JSON.stringify(user));

  saveLoggedInUser(name);

  showMessage("Account created successfully. Entering ChapterNest...", "success");

  setTimeout(function () {
    window.location.href = "index.html";
  }, 900);
});

loginForm.addEventListener("submit", function (event) {
  event.preventDefault();

  const email = document.getElementById("loginEmail").value.trim().toLowerCase();
  const password = document.getElementById("loginPassword").value;
  const savedUser = getSavedUser();

  if (!savedUser) {
    showMessage("No account found. Please sign up first.", "error");
    return;
  }

  if (email === savedUser.email && password === savedUser.password) {
    saveLoggedInUser(savedUser.name);
    showMessage("Login successful. Entering ChapterNest...", "success");

    setTimeout(function () {
      window.location.href = "index.html";
    }, 900);
  } else {
    showMessage("Incorrect email or password.", "error");
  }
});

forgotPassword.addEventListener("click", function (event) {
  event.preventDefault();

  const savedUser = getSavedUser();

  if (!savedUser) {
    showMessage("No account saved yet. Please create an account first.", "error");
  } else {
    showMessage("Saved account email: " + savedUser.email, "success");
  }
});
