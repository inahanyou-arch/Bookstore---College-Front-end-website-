const shelves = [
  { name: "Fiction", url: "fiction.html", desc: "Classic novels and emotional stories" },
  { name: "Fantasy", url: "fantasy.html", desc: "Magic, quests, dragons, and worlds" },
  { name: "Science", url: "science.html", desc: "Space, biology, physics, and discovery" },
  { name: "Romance", url: "romance.html", desc: "Love stories and emotional journeys" },
  { name: "History", url: "history.html", desc: "Civilizations, people, and world events" },
  { name: "Business", url: "business.html", desc: "Money, habits, leadership, and strategy" },
  { name: "Technology", url: "technology.html", desc: "Programming, AI, cybersecurity, and software" },
  { name: "Children", url: "children.html", desc: "Fun stories for young readers" }
];

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => document.querySelectorAll(selector);

function updateCartCount() {
  const countBox = $("#cartCount");
  if (!countBox) return;

  try {
    const cart = JSON.parse(localStorage.getItem("bookCart")) || [];
    countBox.textContent = cart.reduce((sum, item) => sum + Number(item.quantity || 1), 0);
  } catch {
    countBox.textContent = "0";
  }
}

function setupLoader() {
  const loader = $("#pageLoader");
  if (!loader) return;

  window.addEventListener("load", () => {
    setTimeout(() => loader.classList.add("hide"), 450);
  });

  setTimeout(() => loader.classList.add("hide"), 1400);
}

function setupHeader() {
  const header = $("#mainHeader");
  const backTop = $("#backTop");

  function onScroll() {
    if (window.scrollY > 40) {
      header?.classList.add("scrolled");
    } else {
      header?.classList.remove("scrolled");
    }

    if (window.scrollY > 550) {
      backTop?.classList.add("show");
    } else {
      backTop?.classList.remove("show");
    }
  }

  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  backTop?.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
}

function setupMenu() {
  const toggle = $("#menuToggle");
  const nav = $("#navLinks");

  toggle?.addEventListener("click", () => {
    nav?.classList.toggle("open");
    const icon = toggle.querySelector("i");
    if (icon) {
      icon.className = nav?.classList.contains("open") ? "fa-solid fa-xmark" : "fa-solid fa-bars";
    }
  });
}

function setupReveal() {
  const items = $$(".reveal");

  if (!("IntersectionObserver" in window)) {
    items.forEach((item) => item.classList.add("visible"));
    return;
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  items.forEach((item) => observer.observe(item));
}

function setupSearch() {
  const form = $("#siteSearch");
  const input = $("#searchInput");
  const suggestions = $("#searchSuggestions");

  function matchingShelves(value) {
    const q = value.toLowerCase().trim();
    if (!q) return shelves.slice(0, 5);
    return shelves.filter((shelf) => {
      return shelf.name.toLowerCase().includes(q) || shelf.desc.toLowerCase().includes(q);
    }).slice(0, 5);
  }

  function renderSuggestions(value) {
    if (!suggestions) return;

    const matches = matchingShelves(value);
    if (!value.trim()) {
      suggestions.classList.remove("show");
      suggestions.innerHTML = "";
      return;
    }

    suggestions.innerHTML = matches.length
      ? matches.map((shelf) => `<a href="${shelf.url}">${shelf.name}</a>`).join("")
      : `<a href="categories.html">No exact shelf — open categories</a>`;

    suggestions.classList.add("show");
  }

  input?.addEventListener("input", () => renderSuggestions(input.value));

  input?.addEventListener("focus", () => {
    if (input.value.trim()) renderSuggestions(input.value);
  });

  document.addEventListener("click", (event) => {
    if (!form?.contains(event.target)) {
      suggestions?.classList.remove("show");
    }
  });

  form?.addEventListener("submit", (event) => {
    event.preventDefault();
    const q = input?.value.trim().toLowerCase();

    if (!q) {
      window.location.href = "categories.html";
      return;
    }

    const exact = shelves.find((shelf) => shelf.name.toLowerCase().includes(q));
    window.location.href = exact ? exact.url : "categories.html?search=" + encodeURIComponent(q);
  });
}

function setupQuickPanel() {
  const panel = $("#quickPanel");
  const open = $("#openQuickPanel");
  const close = $("#quickClose");
  const input = $("#panelSearchInput");
  const results = $("#quickResults");

  function render(value = "") {
    if (!results) return;

    const q = value.toLowerCase().trim();
    const matches = shelves.filter((shelf) => {
      return !q || shelf.name.toLowerCase().includes(q) || shelf.desc.toLowerCase().includes(q);
    });

    results.innerHTML = matches.map((shelf) => `
      <a href="${shelf.url}">
        <strong>${shelf.name}</strong>
        <span>${shelf.desc}</span>
      </a>
    `).join("");
  }

  open?.addEventListener("click", () => {
    panel?.classList.add("open");
    document.body.classList.add("no-scroll");
    render();
    setTimeout(() => input?.focus(), 100);
  });

  close?.addEventListener("click", () => {
    panel?.classList.remove("open");
    document.body.classList.remove("no-scroll");
  });

  input?.addEventListener("input", () => render(input.value));

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      panel?.classList.remove("open");
      document.body.classList.remove("no-scroll");
    }
  });
}

function setupTilt() {
  const cards = $$(".tilt-card");

  cards.forEach((card) => {
    card.addEventListener("mousemove", (event) => {
      if (window.matchMedia("(max-width: 920px)").matches) return;

      const rect = card.getBoundingClientRect();
      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;
      const rotateY = ((x / rect.width) - 0.5) * 8;
      const rotateX = ((y / rect.height) - 0.5) * -8;

      card.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg) rotate(1.2deg)`;
    });

    card.addEventListener("mouseleave", () => {
      card.style.transform = "rotate(1.2deg)";
    });
  });
}

function setupMagneticButtons() {
  const buttons = $$(".magnetic");

  buttons.forEach((button) => {
    button.addEventListener("mousemove", (event) => {
      if (window.matchMedia("(max-width: 920px)").matches) return;

      const rect = button.getBoundingClientRect();
      const x = event.clientX - rect.left - rect.width / 2;
      const y = event.clientY - rect.top - rect.height / 2;

      button.style.transform = `translate(${x * 0.08}px, ${y * 0.12}px) translateY(-3px)`;
    });

    button.addEventListener("mouseleave", () => {
      button.style.transform = "";
    });
  });
}

function setupCursorGlow() {
  const glow = $("#cursorGlow");
  if (!glow) return;

  window.addEventListener("mousemove", (event) => {
    glow.style.opacity = "1";
    glow.style.left = event.clientX + "px";
    glow.style.top = event.clientY + "px";
  }, { passive: true });

  window.addEventListener("mouseleave", () => {
    glow.style.opacity = "0";
  });
}

function setupShelfHover() {
  const body = document.body;
  $$(".shelf-strip a").forEach((link) => {
    link.addEventListener("mouseenter", () => {
      body.dataset.shelf = link.dataset.shelf || "";
    });
    link.addEventListener("mouseleave", () => {
      body.dataset.shelf = "";
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  setupLoader();
  setupHeader();
  setupMenu();
  setupReveal();
  setupSearch();
  setupQuickPanel();
  setupTilt();
  setupMagneticButtons();
  setupCursorGlow();
  setupShelfHover();
  updateCartCount();
});


function chapterNestGetCart() {
  try {
    return JSON.parse(localStorage.getItem("bookCart")) || [];
  } catch (error) {
    return [];
  }
}

function chapterNestSaveCart(cart) {
  localStorage.setItem("bookCart", JSON.stringify(cart));
}

function chapterNestUpdateCartCount() {
  const countBox = document.getElementById("cartCount");
  if (!countBox) return;

  const cart = chapterNestGetCart();
  countBox.textContent = cart.reduce((sum, item) => sum + Number(item.quantity || 1), 0);
}

function chapterNestShowToast(text) {
  const toast = document.getElementById("cartToast");
  if (!toast) return;

  toast.textContent = text;
  toast.classList.add("show");

  clearTimeout(window.__chapterNestToastTimer);
  window.__chapterNestToastTimer = setTimeout(() => {
    toast.classList.remove("show");
  }, 1200);
}

document.addEventListener("click", function (event) {
  const button = event.target.closest(".quick-add-btn");
  if (!button) return;

  const card = button.closest(".shop-product-card");
  if (!card) return;

  const item = {
    title: card.dataset.title,
    description: card.dataset.description,
    price: card.dataset.price,
    quantity: 1,
    image: card.dataset.image,
    total: card.dataset.price
  };

  const cart = chapterNestGetCart();
  cart.push(item);
  chapterNestSaveCart(cart);
  chapterNestUpdateCartCount();

  button.textContent = "Added";
  button.classList.add("added");
  chapterNestShowToast(item.title + " added to cart");

  setTimeout(() => {
    button.textContent = "Add to Cart";
    button.classList.remove("added");
  }, 900);
});

document.addEventListener("DOMContentLoaded", chapterNestUpdateCartCount);


document.addEventListener("DOMContentLoaded", function () {
  const logoutLink = document.getElementById("logoutLink");
  if (!logoutLink) return;

  logoutLink.addEventListener("click", function (event) {
    event.preventDefault();

    localStorage.removeItem("chapterNestLoggedIn");
    localStorage.removeItem("chapterNestLoggedInUser");
    localStorage.removeItem("bookstoreLoggedIn");
    localStorage.removeItem("bookstoreLoggedInUser");

    window.location.href = "login_signup.html";
  });
});
